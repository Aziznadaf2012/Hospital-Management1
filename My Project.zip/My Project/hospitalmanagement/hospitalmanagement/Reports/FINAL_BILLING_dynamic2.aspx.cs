﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace hospitalmanagement.Reports
{
    public partial class FINAL_BILLING_dynamic2 : System.Web.UI.Page
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            cn = new SqlConnection();
            cn.ConnectionString = "Data Source=DESKTOP-9QM1BCB\\SQLEXPRESS;Initial Catalog=hospitalmanagement;Integrated Security=True";
            cn.Open();

            if (!IsPostBack)
                Setdropdown();
        }

        public void Setdropdown()
        {
            cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "Select*from IPD_MASTER";
            dr = cmd.ExecuteReader();
            DropDownList1.DataSource = dr;
        
            DropDownList1.DataValueField = "IPD_ID";
            DropDownList1.DataBind();
            dr.Close();
        }

        protected void btn_show_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select IPD_BILL_ID,DEPT_NM,IPD_MASTER.IPD_ID,CASEPAPER.CASEPAPER_ID,BILL_DATE,NURSING_CHARGES,BED_CHARGES,TEST_AMOUNT,OPERATION_CHARGES,GST,TOTAL_AMOUNT from DEPARMENT,IPD_MASTER,CASEPAPER,FINAL_BILLING where DEPARMENT.DEPT_ID=FINAL_BILLING.DEPT_ID and IPD_MASTER.IPD_ID=FINAL_BILLING.IPD_ID and CASEPAPER.CASEPAPER_ID=FINAL_BILLING.CASEPAPER_ID and FINAL_BILLING.IPD_ID=" + DropDownList1.SelectedValue;
            dr = cmd.ExecuteReader();
            PlaceHolder1.Controls.Add(new LiteralControl("<table class='table' border= '2px' id='bill'><tr><th>BILL NO</th> <th>DEPARTMENT</th> <th>IPD</th> <th>CASEPAPER NO</th> <th>DATE</th> <th>NURSING CHARGES</th> <th>BED CHARGES</th> <th>TEST AMOUNT</th> <th>OPERATION CHARGES</th> <th>GST</th> <th>TOTAL AMOUNT</th> </tr>"));

            while (dr.Read())
            {
                PlaceHolder1.Controls.Add(new LiteralControl("<tr>"));

                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[0] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[1] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[2] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[3] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[4] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[5] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[6] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[7] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[8] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[9] + "</td>"));
                PlaceHolder1.Controls.Add(new LiteralControl("<td>" + dr[10] + "</td>"));



                PlaceHolder1.Controls.Add(new LiteralControl("</tr>"));


            }
            PlaceHolder1.Controls.Add(new LiteralControl("</table>"));
            dr.Close();
        }
    }
}